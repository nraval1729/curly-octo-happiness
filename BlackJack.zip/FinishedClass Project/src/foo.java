import java.util.*;
public class foo {
	public static void main(String[] args) {
		System.out.println("\u2764123");
	}
}
